#ifndef IMPLICITGRID3D_H
#define IMPLICITGRID3D_H

namespace plb {
  template<typename T, template<typename U> class Descriptor> struct ImplicitGrid3D;
}
#include "core/globalDefs.h"
#include "atomicBlock/blockLattice3D.h"

namespace plb {
  template<typename T, template<typename U> class Descriptor>
  struct ImplicitGrid3D {
          BlockLattice3D<T,Descriptor>& parent;
          const int nX,nY,nZ;
          ImplicitGrid3D(BlockLattice3D<T,Descriptor>& parent_) 
         : parent(parent_), nX(parent.getNx()), nY(parent.getNy()), nZ(parent.getNz()) {}
          const Cell<T,Descriptor> & operator () (int x,int y,int z) const {
            return parent.rawData[z + nZ*(y+nY*x)];
          };
          Cell<T,Descriptor> & operator () (int x,int y,int z) {
            return parent.rawData[z + nZ*(y+nY*x)];
          };
  };
}
#endif